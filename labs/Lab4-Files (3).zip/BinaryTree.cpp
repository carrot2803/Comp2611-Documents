#include <iostream>
#include <cstdlib>
#include "BinaryTree.h"
#include "Stack.h"

using namespace std;


// Code for Lab #3, Question 3 functions

BTNode * createBTNode (int data) {
	BTNode * newNode; 
   
	newNode = new BTNode;
   
	newNode->data = data;
	newNode->left = NULL;
	newNode->right = NULL;
   
	return newNode;
}



void preOrder (BTNode * root) {
	
	if (root == NULL)
		return;
		
	cout << root->data << " ";

	preOrder (root->left);
	preOrder (root->right);
}



void inOrder (BTNode * root) {
	
	if (root == NULL)
		return;

	inOrder (root->left);
	
	cout << root->data << " ";
	
	inOrder (root->right);
}



void postOrder (BTNode * root) {
	
	if (root == NULL)
		return;

	postOrder (root->left);
	postOrder (root->right);
	
	cout << root->data << " ";
}



// Write code for Lab #4, Question 1 functions here

int moment (BTNode * root) {

	return 0;
	
}



int numOneChild (BTNode * root) {

	return 0;
	
}



int numTerminal (BTNode * root) {

	return 0;
}



int maximum (BTNode * root) {

	return INT_MIN;

}



// Write the code for non-recursive inorder traversal here

void inOrderNonRecursive (BTNode * root) {

	Stack * s = initStack ();
	
	BTNode * curr;
	bool finished;
	
	curr = root;
	finished = false;
	
	while (!(finished)) {
		// Convert algorithm to code. Note that the Stack is used to
		//   store the address of BT nodes, not the data. See Stack.h.
	}

	return;
}



// Write the code for non-recursive preorder traversal here

void preOrderNonRecursive (BTNode * root) {

	return;

}



