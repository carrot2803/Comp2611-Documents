#include <iostream>
#include <cstdlib>
#include "BinaryTree.h"

using namespace std;


// write code for Lab #3, Question 3 functions here

BTNode * createBTNode (int data) {

	return NULL;
}



void preOrder (BTNode * root) {

	return;
}



void inOrder (BTNode * root) {

	return;	
}



void postOrder (BTNode * root) {
	
	return;
}

