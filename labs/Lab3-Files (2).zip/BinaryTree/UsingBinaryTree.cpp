#include <iostream>
#include "BinaryTree.h"

using namespace std;

int main() {
  
	BTNode * root;
	BTNode * node1, * node2, * node3, * node4, * node5, * node6, * node7, * node8;
	
	// Write code to create binary tree and test traversals in Question 3
	 
	node1 = createBTNode (30);
	node2 = createBTNode (10);
	
	// Connect node1 and node2 like this:
	
	// node1->left = node2;
	
	// set root to the address of the node with 30:
	
	// write code for 3(d) to test traversals:

	return 0;
}

