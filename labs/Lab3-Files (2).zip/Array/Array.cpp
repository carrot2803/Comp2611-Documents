#include <iostream>
#include <cstdlib>
#include "Array.h"

using namespace std;

// insert function definitions for Lab #3, Question 1

void printArrayRec (int a[], int start, int n) {
	
	return;

}



bool containsArrayRec (int a[], int start, int n, int key) {
	
	return false;
	
}



int sumArrayRec (int a[], int start, int n) {

	return 0;
	
}



int maxArrayRec (int a[], int start, int n) {

	return INT_MIN;
}



bool binarySearchRec (int a[], int start, int end, int key) {
	
	return false;

}

