#include <iostream>
#include <cstring>
#include "MaxHeap.h"
   using namespace std;


int main () {

	MaxHeap * heap;
	char filename [25];	
	bool isHeap;
	
	// Question 2

	cout << "Question 2" << endl;
	

	// Question 3

	cout << endl << endl;
	cout << "Question 3" << endl;
		

	// Question 4

	cout << endl << endl;
	cout << "Question 4" << endl;
				

	// Question 5
	
	cout << endl << endl;
	cout << "Question 5" << endl;
	
		
	return 0;
}
