#include <iostream>
#include <fstream>
#include "MaxHeap.h"
   using namespace std;

MaxHeap * initMaxHeap() {
	MaxHeap * heap;
	
	heap = new MaxHeap;
	heap->size = 0;
	
	return heap;
}



MaxHeap * initMaxHeapFromArray (int A[], int numElements) {

	MaxHeap * heap;
	
	heap = new MaxHeap;
	
	for (int i=0; i<numElements; i++) {
		heap->A[i+1] = A[i];
	}
	
	heap->size = numElements;

	return heap;
}



MaxHeap * initMaxHeapFromFile (char filename[100]) {

	ifstream inputFile;
	MaxHeap * heap;
	int index;
	int num;
	
	inputFile.open (filename);
	
	if (!inputFile.is_open()) {
		cout << "File could not be opened to create heap: " << filename << endl;
		return NULL;
	}

	heap = new MaxHeap;
	
	index = 0;
		
	inputFile >> num;
	while (!inputFile.eof()) {
		index++;
		heap->A[index] = num;
		inputFile >> num;
	}
	
	inputFile.close();
	
	heap->size = index;		
	
	return heap;
}



// Write the code for the following functions (Lab #6, Part 2)

void displayMaxHeap (MaxHeap * heap) {
	
	return;
}



int sizeMaxHeap (MaxHeap * heap) {

	return 0;
}



bool isEmptyMaxHeap (MaxHeap * heap) {

	return true;
}



bool maxHeapPropertyHolds (MaxHeap * heap, int i) {
	
	return false;
}



bool isMaxHeap (MaxHeap * heap) {

	return false;
}
