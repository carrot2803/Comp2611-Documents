#include <iostream>
#include <cstdlib>
#include "LinkedList.h"

using namespace std;

int main() {
  
   Node *top, *last, *node;
   int numElements;

   cout << "Dev-C++ Project: Linked List Operations for Question 2" << endl;
   cout << "======================================================" << endl;
   cout << endl;

   // copy code from main() function in Question 2
   
    
   cout << "\n*** End of Linked List Operations ***" << endl;

   return 0;
}
