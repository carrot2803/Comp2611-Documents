#include <iostream>
#include <cstdlib>

using namespace std;

struct Node {
   int data;
   Node * next;
};


// function prototypes

Node * createNode (int n);
void printList (Node * top);


// implementation of functions

Node * createNode (int n) {
   Node * newNode; 
   
   newNode = new Node;
   newNode->data = n;
   newNode->next = NULL;
   
   return newNode;
}


void printList (Node * top) {

   Node * curr;
   
   curr = top;
   while (curr != NULL) {
      cout << curr -> data << "\t";
      curr = curr->next;
   }

   cout << "\n";
   
}


int main() {
  
   Node * top;
   Node * newNode;
   
   // write code for Question 1
   
   return 0;
}


