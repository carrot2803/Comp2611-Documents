#include <iostream>
#include "MaxHeap.h"
#include "MaxPriorityQueue.h"

using namespace std;

MaxPriorityQueue * initMaxPQ (int A[], int numElements) {
	return NULL;

}


int maximumPQ (MaxPriorityQueue * maxPQ) {

	return -1;
}


int extractMaximumPQ (MaxPriorityQueue * maxPQ) {

	return -1;
}


void insertMaxPQ (MaxPriorityQueue * maxPQ, int priority) {
	return;
}


void increasePriority (MaxPriorityQueue * maxPQ, int i, int newPriority) {
	return;

}


void displayMaxPQ (MaxPriorityQueue * maxPQ) {
	displayMaxHeap (maxPQ->heap);
}

