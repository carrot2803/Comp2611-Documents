#include <iostream>
#include <cstdlib>

#include "NodeTypes.h"
#include "BinaryTree.h"
#include "BinarySearchTree.h"

using namespace std;


// Write insertBST function here (Lab #5, Question 2) 

BTNode * insertBST (BTNode * root, int data) {
	
	BTNode * newNode;
	BTNode * curr;
	
	newNode = createBTNode (data);
	
}



// Write insertBSTRec function here (Lab #5, Question 9) 

BTNode * insertBSTRec (BTNode * root, int data) {
	
	return root;
	
}




// Write containsBST function here (Lab #5, Question 3) 

BTNode * containsBST (BTNode * root, int key) {

	return NULL;
	
}



// Write deleteLeafNode function here (Lab #5, Question 5)

bool deleteLeafNode (BTNode * node) {

	return false;	
}
