#include <iostream>
#include "BinaryTree.h"
#include "BinarySearchTree.h"

using namespace std;

int main() {
  
	BTNode * root;	

	// Write code to create binary search tree and test functions (Lab #5, Questions 6-8)	

	root = NULL;

	// Write code to create binary search tree using insertBSTRec function (Lab #5, Question 10)	

				
	return 0;
}

