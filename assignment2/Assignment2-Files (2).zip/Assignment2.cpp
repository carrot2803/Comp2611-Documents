#include <iostream>

using namespace std;

#include "Graph.h"



int main() {

	Graph * graph;
	
	// Write code here to process the Commands file 
			
	return 0;	
		
}


