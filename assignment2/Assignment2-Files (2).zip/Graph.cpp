#include <iostream>
#include <fstream>
#include <cstdlib>

using namespace std;

#include "Graph.h"

    
Vertex newVertex (string ID) {
	
	Vertex vertex;
	
	// write code here to create a new Vertex struct with the given ID
	
	return vertex;
}



Edge * newEdge (string dest) {
	
	Edge * edge;
	
	// write code here to create a new Edge struct with the given destination ID
	
	return edge;
}



int findVertex (Graph * graph, string ID) {

	// write code here to find and return the location of the vertex with 
	//   the given ID in the graph or -1 if it is not present
	
	return -1;			// -1 indicates that a vertex with the ID was not found.
}



// This function adds an edge source->dest to the graph

bool addEdge (Graph * graph, string sourceID, string destID) {
	
	return false;
}



// This function checks if the edge X->Y is present in the graph

bool hasEdge (Graph * graph, string X_ID, string Y_ID) {

	return false;
}



// This function deletes the edge X->Y from the graph, if it is present

bool deleteEdge (Graph * graph, string X_ID, string Y_ID) {

	return false;
}



// This function checks if the graph contains the vertex, X

bool hasVertex (Graph * graph, string X_ID) {
	
	return false;
}



// This function returns the out degree of vertex X, if it exists

int outDegree (Graph * graph, string X_ID) {
	
	return 0;
}



// This function copies all the vertices adjacent to vertex X in the 
//   graph (i.e., outgoing edges) into the outgoing array passed as 
//   a parameter. It returns the number of vertices in the array or 
//   -1, if X does not exist. 

int outgoingEdges (Graph * graph, string X_ID, string outgoing[]) {
	
	return 0;
}



// This function copies all the vertices X such that an edge (X, Y)
//   exists (i.e., incoming edges) into the incoming array passed as 
//   a parameter. It returns the number of vertices in the array or 
//   -1, if Y does not exist. 

int incomingEdges (Graph * graph, string Y_ID, string incoming[]) {
	
	return 0;
}



// This function displays the graph on the monitor

void displayGraph (Graph * graph) {
	
	return;

}



Graph * readGraph (char fileName[]) {
	
	ifstream graphFile;
	
	graphFile.open (fileName);
	
	if (!graphFile.is_open()) {
		cout << "Error opening graph input file : " << fileName;
		cout << ". Aborting ..." << endl;
		return NULL;
	}
	
	Graph * newGraph = new Graph;
	
	
	// Read number of vertices from the first line of the file.
	
	
	// Read name of each vertex (vertexID) from the second line of the file
	//  and store in array of vertices.
	
	
	// Read edges from each vertex from remaining lines of the file and
	//  store in linked list of edges connected to array location for the
	//  predecessor vertex. 
	
	
	graphFile.close();
	
	return newGraph;
	
}
