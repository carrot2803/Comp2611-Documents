#ifndef _GRAPH_H
#define _GRAPH_H

#define MAX_VERTICES 100

struct Edge {
	string destID;
	Edge * nextEdge;
};

struct Vertex {
	string ID;
	Edge * firstEdge;
};

struct Graph {
	int numVertices;
	Vertex vertices[MAX_VERTICES];
};

Vertex newVertex (string ID);
Edge * newEdge (string dest);
int findVertex (Graph * graph, string ID);
bool addEdge (Graph * graph, string u, string v);
bool hasEdge (Graph * graph, string u, string v);
bool deleteEdge (Graph * graph, string u, string v);
bool hasVertex (Graph * graph, string v);
int outDegree (Graph * graph, string v);
int outgoingEdges (Graph * graph, string v, string outgoing[]);
int incomingEdges (Graph * graph, string v, string incoming[]);
void displayGraph (Graph * graph);
Graph * readGraph (char fileName[]);


#endif
